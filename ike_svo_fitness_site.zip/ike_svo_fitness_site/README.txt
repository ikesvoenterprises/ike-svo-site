IKE SVO PERFORMANCE WEBSITE

WHAT IS INCLUDED
- Premium black-and-gold fitness website
- Product cards for workout and nutrition plans
- Mobile-friendly design
- Payment-ready Buy Now buttons
- FAQ and health disclaimer
- One-file preview plus full website folder

HOW TO VIEW
1. Unzip the folder.
2. Open index.html.

HOW TO PUBLISH
1. Create a free Netlify account.
2. Choose Add new project.
3. Choose Deploy manually.
4. Upload the unzipped ike_svo_fitness_site folder.

HOW TO CONNECT PAYMENTS
The current Buy Now buttons are placeholders.
You can connect them to:
- Stripe Payment Links
- Payhip
- Gumroad
- Lemon Squeezy

For automatic file delivery, Payhip, Gumroad, or Lemon Squeezy is easiest.
Create the product there, upload the PDF/files, copy the checkout link,
and replace href="#" on the matching Buy Now button with your checkout link.

IMPORTANT
The products shown are placeholders. The actual workout plans, nutrition guide,
tracking sheets, product images, policies, and checkout links still need to be created.
